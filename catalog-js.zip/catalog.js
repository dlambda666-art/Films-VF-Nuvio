import { discoverMovies, getMovie } from "./tmdb.js";
import { CONFIG } from "./config.js";
import { getVerifiedVFIds } from "./vf.js";

const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

function isForeign(movie) {
  const original = String(movie.original_language || "").toLowerCase();
  return original !== "fr";
}

function score(movie) {
  const popularity = Math.min(Number(movie.popularity || 0) * 4, 500);
  const rating = Number(movie.vote_average || 0) * 10;
  const votes = Number(movie.vote_count || 0);

  let voteBonus = 0;
  if (votes >= 10000) voteBonus = 150;
  else if (votes >= 5000) voteBonus = 100;
  else if (votes >= 1000) voteBonus = 50;

  return popularity + rating + voteBonus;
}

function toMeta(movie, vfRecord) {
  return {
    id: `tmdb-${movie.id}`,
    type: "movie",
    name: movie.title || movie.original_title,
    poster: movie.poster_path ? `${IMAGE_BASE}${movie.poster_path}` : undefined,
    background: movie.backdrop_path
      ? `https://image.tmdb.org/t/p/w1280${movie.backdrop_path}`
      : undefined,
    description: movie.overview || "",
    releaseInfo: movie.release_date || "",
    imdbRating: movie.vote_average || undefined,
    genres: movie.genre_ids || [],
    posterShape: "poster",
    behaviorHints: {
      defaultVideoId: `tmdb-${movie.id}`
    },
    meta: {
      tmdb_id: movie.id,
      vf: true,
      vf_country: vfRecord?.vf_country || null,
      vf_source: vfRecord?.source || null
    }
  };
}

async function getCandidates() {
  const pages = [];

  for (let page = 1; page <= CONFIG.tmdbPages; page++) {
    pages.push(
      discoverMovies({
        page,
        with_original_language: "en|es|de|it|ja|ko|zh|hi|pt|ru|nl|sv|da|no|pl|tr",
        without_genres: [...CONFIG.excludedMovieGenres].join(",")
      })
    );
  }

  const results = (await Promise.all(pages)).flatMap(x => x.results || []);

  const unique = new Map();
  for (const movie of results) {
    if (!movie?.id || !isForeign(movie)) continue;
    if (CONFIG.excludedMovieGenres.has(movie.genre_ids?.find(id => CONFIG.excludedMovieGenres.has(id)))) continue;
    unique.set(movie.id, movie);
  }

  return [...unique.values()];
}

export async function buildCatalog(catalogId) {
  const vfIds = await getVerifiedVFIds();
  if (!vfIds.size) return [];

  const candidates = await getCandidates();
  const metas = [];

  for (const movie of candidates) {
    if (!vfIds.has(movie.id)) continue;

    const genreId = CONFIG.genreMap[catalogId];

    if (genreId && !(movie.genre_ids || []).includes(genreId)) continue;

    if (catalogId === "nouveautes-vf-2026" && !String(movie.release_date || "").startsWith("2026")) continue;
    if (catalogId === "vf-2025" && !String(movie.release_date || "").startsWith("2025")) continue;

    const vfRecord = await getMovieVFRecord(movie.id);
    metas.push({
      movie,
      vfRecord,
      rank: score(movie)
    });
  }

  metas.sort((a, b) => b.rank - a.rank);

  return metas
    .slice(0, CONFIG.maxResults)
    .map(({ movie, vfRecord }) => toMeta(movie, vfRecord));
}

async function getMovieVFRecord(id) {
  const vfIds = await getVerifiedVFIds();
  if (!vfIds.has(id)) return null;
  return { source: "verified-vf-index" };
}
