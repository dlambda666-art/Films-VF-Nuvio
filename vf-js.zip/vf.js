const VF_INDEX_URL = process.env.VF_INDEX_URL || "";

const cache = new Map();
const CACHE_TTL = 15 * 60 * 1000;

function normalize(item) {
  if (!item || item.tmdb_id == null) return null;

  const tmdb_id = Number(item.tmdb_id);
  if (!Number.isInteger(tmdb_id) || tmdb_id <= 0) return null;

  const status = String(item.status || "confirmed").toLowerCase();

  return {
    tmdb_id,
    vf_confirmed: item.vf_confirmed !== false && status !== "pending",
    vf_country: item.vf_country || null,
    source: item.source || "unknown",
    confidence: Number(item.confidence ?? 1),
    status,
    last_verified: item.last_verified || null
  };
}

async function loadIndex() {
  if (!VF_INDEX_URL) return [];

  const cached = cache.get(VF_INDEX_URL);
  if (cached && Date.now() - cached.time < CACHE_TTL) {
    return cached.data;
  }

  const response = await fetch(VF_INDEX_URL);

  if (!response.ok) {
    throw new Error(`VF index ${response.status}`);
  }

  const payload = await response.json();
  const list = Array.isArray(payload) ? payload : payload.items;

  if (!Array.isArray(list)) {
    throw new Error("VF index must contain an array");
  }

  const data = list
    .map(normalize)
    .filter(Boolean)
    .filter(item => item.vf_confirmed);

  cache.set(VF_INDEX_URL, { time: Date.now(), data });
  return data;
}

export async function getVerifiedVFIds() {
  const index = await loadIndex();
  return new Set(index.map(item => item.tmdb_id));
}

export async function getVFRecord(tmdbId) {
  const index = await loadIndex();
  return index.find(item => item.tmdb_id === Number(tmdbId)) || null;
}

export function clearVFCache() {
  cache.clear();
}
